#include <stdio.h>
int main()
{
 int n;
  printf("enter posetive integer number :\n");
   scanf("%d",&n);
 char a[n+1];
  printf("enter a phrase :\n");
   scanf("%s",a);
  while(n>=1)
  {
    for(int i=0;i<n;i++)
    {
      if(a[i] == a[i+1])
      {
        a[i]=a[i+2];
         printf("%s\n",a);
        
      }
      else
        a[i]=a[i];
        
    }
  }
}